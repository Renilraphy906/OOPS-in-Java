package com.aitrich.inventorysystem.read;

import java.util.Scanner;

import com.aitrich.inventorysystem.domain.Customer;

public class CustomerRead {
	
	public Customer addCustomer()
	{
		String cn,ba,ea;
		
		Scanner s = new Scanner(System.in);
		
		s.nextLine();
		
		System.out.println("Enter the Customer Name   ::    ");
		 cn = s.nextLine();
		 
		 s.nextLine();
		 
		 System.out.println("Enter the Billing Address");
		 ba = s.next();
		 
		 s.nextLine();
		 
		 System.out.println("Enter the Email Address");
		 ea = s.next();
		 
		 Customer cus = new Customer(cn,ba,ea);
		 
		 return cus;
		 
	}

}

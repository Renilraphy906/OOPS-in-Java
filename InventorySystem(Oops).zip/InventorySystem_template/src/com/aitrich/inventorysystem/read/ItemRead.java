package com.aitrich.inventorysystem.read;


import java.util.Scanner;

import com.aitrich.inventorysystem.data.DataAccessObject;
import com.aitrich.inventorysystem.domain.Item;
import com.aitrich.inventorysystem.services.ItemService;

public class ItemRead {

	//itemnumber,itemname,unitprice;
	
	int itemnumber;
	String itemname;
	float unitprice;
	DataAccessObject dao = null;
	ItemService is = new ItemService(dao);
	
	public Item itemEnter()
	{
		Scanner ab = new Scanner(System.in);
		
			System.out.println("Enter the Item Number  ::  ");
			itemnumber = ab.nextInt();
			
			ab.nextLine();
			
			System.out.println("Enter the Item Name   ::   ");
			itemname = ab.nextLine();
			
			System.out.println("Enter the Unit Price   ::   ");
			unitprice = ab.nextFloat();
		
			
			Item it = new Item(itemnumber,itemname,unitprice);
			
			//is.addItem(it);
			return it;
	}	
}
 

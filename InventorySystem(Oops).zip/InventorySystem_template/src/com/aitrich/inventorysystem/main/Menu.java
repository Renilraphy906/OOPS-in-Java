package com.aitrich.inventorysystem.main;

import java.io.IOException;
import java.util.Scanner;

import com.aitrich.inventorysystem.data.CustomerDataAccessObject;
import com.aitrich.inventorysystem.data.FileDataAccessObject;
import com.aitrich.inventorysystem.data.ItemDataAccessObject;
import com.aitrich.inventorysystem.domain.Customer;
import com.aitrich.inventorysystem.domain.Item;
import com.aitrich.inventorysystem.read.CustomerRead;
import com.aitrich.inventorysystem.read.ItemRead;
import com.aitrich.inventorysystem.services.CustomerService;
import com.aitrich.inventorysystem.services.ItemService;

public class Menu {
	
	public void menuItem() throws IOException
	{
		int a;
		
		
		ItemRead ir = new ItemRead();
		CustomerRead cr = new CustomerRead();
		FileDataAccessObject fdao = new ItemDataAccessObject("Files/item.txt");
		FileDataAccessObject fdaoCus = new CustomerDataAccessObject("Files/Customer.txt");
		ItemService is = new ItemService(fdao);
		CustomerService cs = new CustomerService(fdaoCus);
				
		Scanner obj  = new Scanner(System.in);
		
		System.out.println("Select any Option!!!");
		System.out.println("1.Add Items.");
		System.out.println("2.View Items.");
		System.out.println("3.Add Customer.");
		System.out.println("4.View Customer.");
		System.out.println("5.Search Customer starts with S.");
		System.out.println("6.Check Price.");
		System.out.println("7.Exit.");
		System.out.println();
		System.out.println("Enter Your Option...");
		a = obj.nextInt();

		
		switch(a)
		{
		case 1:is.addItem(ir.itemEnter());
			   break;
			   
		case 2 : Item[] it = is.findAllItem();
			     for(Item n : it)
			     {
			    	 System.out.println(n);
			     }
				break;
				
		case 3:cs.addCustomer(cr.addCustomer());
		       break;
		   
		case 4 : Customer[] cus = cs.findAllCustomers();
				for(Customer n : cus)
				{
					System.out.println(n);
				}
			     break;
			     
		case 5 : cs.searchCustomerName();
				break;
				
		case 6 : is.priceCheck();
				break;
			
		case 7 : System.out.println("Succesfully Exited!!!"); 
				System.exit(0);
			   
	    default : System.out.println("Invalid Entry!!!");
	    		  System.exit(0);
			      break;
			     
		}
	
	}

}

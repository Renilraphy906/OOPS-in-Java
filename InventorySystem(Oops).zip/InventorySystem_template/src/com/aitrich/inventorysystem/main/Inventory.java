package com.aitrich.inventorysystem.main;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import com.aitrich.inventorysystem.data.CustomerDataAccessObject;
import com.aitrich.inventorysystem.data.FileDataAccessObject;
import com.aitrich.inventorysystem.data.ItemDataAccessObject;
import com.aitrich.inventorysystem.read.CustomerRead;
import com.aitrich.inventorysystem.read.ItemRead;
import com.aitrich.inventorysystem.services.CustomerService;
import com.aitrich.inventorysystem.services.ItemService;

public class Inventory {
	
	public static void main(String[] args) throws IOException{
	
		try
		{
			String s;
			
			Menu menu = new Menu();
			
 			Scanner obj = new Scanner(System.in);
			
						
			do
			{
				menu.menuItem();
				
				System.out.println("Do you want to continue?(y/n)");
				s = obj.next(); 
			
			}while(s.equals("y"));
			
			if(!s.equals("y"))
			{
				if(s.equals("n"))
				{
					System.out.println("Succesfully Exited!!!");
					System.exit(0);
				}
				else
				{
					System.out.println("You are Exited...Invalid Entry!!!");
					System.exit(0);
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}

//		ItemRead ir = new ItemRead();
//		CustomerRead cr = new CustomerRead();
//		FileDataAccessObject fdao = new ItemDataAccessObject("Files/item.txt");
//		FileDataAccessObject fdaoCus = new CustomerDataAccessObject("Files/Customer.txt");
//		ItemService is = new ItemService(fdao);
//		CustomerService cs = new CustomerService(fdaoCus);
//		
//		is.priceCheck();
	}
}

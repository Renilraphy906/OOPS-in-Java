package com.aitrich.inventorysystem.services;



import java.io.IOException;
import java.util.Scanner;

import javax.swing.text.DefaultEditorKit.InsertBreakAction;

import com.aitrich.inventorysystem.data.DataAccessObject;
import com.aitrich.inventorysystem.data.FileDataAccessObject;
import com.aitrich.inventorysystem.data.ItemDataAccessObject;
import com.aitrich.inventorysystem.domain.Item;
public class ItemService
{
	private DataAccessObject dao;
	Object obj;
	private int flag=0;
	
	
	public ItemService(DataAccessObject dao) {
		super();
		this.dao = dao;
	}

	public void addItem(Item item){
		
		dao.insert(item);
		
		
	}
	
	public Item[] findAllItem() throws IOException {
		
		int j=0;
		
		Object[] obj = dao.findAll();
		
		for(Object n: obj)j++;
		Item[] it = new Item[j];
		
		for(int i=0;i<j;i++)
		{
			it[i] = (Item) obj[i];			
		}
		//create a list and add all item list by calling
		 
		return it;
	}
	
	public void priceCheck() throws IOException
	{
		this.flag = 0;
		
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter the amount...");
		float fl = obj.nextFloat();
		
		Item[] ite =findAllItem();
		for(Item n : ite)
		{
			float f = n.getUnitprice();
			if(f>fl)
			{
				this.flag = 1;
				System.out.println(n);
			}
		}
		if(flag == 0)
		{
			System.out.println("All items are below Rs."+fl+"/-");
			
		}
	}
	 
}

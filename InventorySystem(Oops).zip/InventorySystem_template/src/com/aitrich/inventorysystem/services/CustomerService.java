package com.aitrich.inventorysystem.services;


import java.io.IOException;

import com.aitrich.inventorysystem.data.CustomerDataAccessObject;
import com.aitrich.inventorysystem.data.DataAccessObject;
import com.aitrich.inventorysystem.data.FileDataAccessObject;
import com.aitrich.inventorysystem.domain.Customer;
import com.aitrich.inventorysystem.domain.Item;

public class CustomerService 
{
	private DataAccessObject dao;
	private int flag=0;

	public CustomerService(DataAccessObject dao) {
		super();
		this.dao = dao;
	}

	 
public void addCustomer(Customer customer){
	
	dao.insert(customer);
	 	
	}
	 
	 
	public Customer[] findAllCustomers() throws IOException 
	{
		int i = 0;
		//create a list and add all customer list by calling
		Object[] obj = dao.findAll() ;
		for(Object n: obj)i++;
		Customer[] cus = new Customer[i];
		for(int j=0; j<i; j++)
		{
			cus[j] = (Customer) obj[j];
		}
	
		return cus;
	}
	
	public void searchCustomerName() throws IOException
	{
		int i=0;
		this.flag=1;
		char a = 's';
		char b = 'S';
		
		Customer[] cus = findAllCustomers();
		for(Customer n : cus)
			{
				String s = n.getCustomername();
				char c = s.charAt(0);
				if(c == a)
				{
					this.flag = 0;
					System.out.println(n);
				}
				else if(c == b)
				{
					this.flag = 0;
					System.out.println(n);
				}
			}
		if(flag==1)
		{
			System.out.println("Does not exist!!!");
		}
	}
}

package com.aitrich.inventorysystem.data;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;



public interface DataAccessObject {
	void insert(Object object);
	
	Object[] findAll() throws IOException;
}

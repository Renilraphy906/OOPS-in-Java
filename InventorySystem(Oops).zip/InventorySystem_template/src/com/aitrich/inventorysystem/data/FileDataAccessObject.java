package com.aitrich.inventorysystem.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import com.aitrich.inventorysystem.domain.Customer;
import com.aitrich.inventorysystem.domain.Item;

public abstract class FileDataAccessObject implements DataAccessObject{
	FileWriter fw;
	FileReader fr;
	BufferedWriter writeToFile;
	BufferedReader readFromFile;
	BufferedReader read;
	private String persistenceFilePath;
	
	Object[] data;
	
	public FileDataAccessObject(String persistenceFilePath) {
		super();
		this.persistenceFilePath = persistenceFilePath;
	}
	public String getPersistenceFilePath() {
		return persistenceFilePath;
	}
	public void setPersistenceFilePath(String persistenceFilePath) {
		this.persistenceFilePath = persistenceFilePath;
	}
	
	@Override
	public void insert(Object object) {
		
		String s = objectToCSVRecord(object);
		
		File file = new File(persistenceFilePath);
	
		try
		{
			
		
			if(!file.exists())
			{
				file.createNewFile();
			}
			else
			{
		
				fw = new FileWriter(file,true);
				writeToFile = new BufferedWriter(fw);
				writeToFile.write(s);
				writeToFile.newLine();
				writeToFile.close();
				System.out.println(s);
				System.out.println("Inserted Successfully!!!!");
		}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	}
	
	@Override
	public Object[] findAll() throws IOException {

		int j = 0;
		
			File file = new File(persistenceFilePath);
			fr = new FileReader(file);
			BufferedReader br = new BufferedReader(fr);
			
			while (br.readLine() != null)
				{
					j++;
				}
			fr.close();

			Object[] obj = new Object[j];
			FileReader fr4 = new FileReader(file);
			BufferedReader br1 = new BufferedReader(fr4);
			String s;
			int i = 0;
			
			while((s = br1.readLine()) != null)
			{
				obj[i] = csvRecordToObject(s);
				i++;
			}
			fr4.close();
		
		//read all records from file
		 return obj;
		
	}

	protected abstract String objectToCSVRecord(Object object);

	
	protected abstract Object csvRecordToObject(String cvsRecord);
}

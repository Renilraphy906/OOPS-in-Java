package com.aitrich.inventorysystem.data;

import com.aitrich.inventorysystem.domain.Customer;

public class CustomerDataAccessObject extends FileDataAccessObject{
	
	
	StringBuilder sb=new StringBuilder();
	public CustomerDataAccessObject(String persistenceFilePath) {
		super(persistenceFilePath);
	}
	
	
	@Override
	protected String objectToCSVRecord(Object object) {
	
		Customer cs = (Customer) object;
		StringBuilder sb = new StringBuilder();
		sb.append(cs.getCustomername());
		sb.append(",");
		sb.append(cs.getBillingaddress());
		sb.append(",");
		sb.append(cs.getEmailaddress());
		
		String s = String.valueOf(sb);
		//convert object to customer and make a csv record
		 return s;
	}
	@Override
	protected Object csvRecordToObject(String cvsRecord) {
		 
		String[] str = cvsRecord.split(",");
		
		String a = String.valueOf(str[0]);
		String b = String.valueOf(str[1]);
		String c = String.valueOf(str[2]);
		
		Customer cus = new Customer(a,b, c);
		
		return cus;
	}
}

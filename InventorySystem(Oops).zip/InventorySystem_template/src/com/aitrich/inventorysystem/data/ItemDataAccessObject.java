package com.aitrich.inventorysystem.data;

import com.aitrich.inventorysystem.domain.Customer;
import com.aitrich.inventorysystem.domain.Item;
import com.aitrich.inventorysystem.read.ItemRead;


public class ItemDataAccessObject extends FileDataAccessObject{
	 
	
	
	public ItemDataAccessObject(String persistenceFilePath) {
		super(persistenceFilePath);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	protected String objectToCSVRecord(Object object) {
		
		
		Item it = (Item)object;
		
		StringBuilder sb = new StringBuilder();
		sb.append(it.getItemnumber());
		sb.append(",");
		sb.append(it.getItemname());
		sb.append(",");
		sb.append(it.getUnitprice());
		
		String a = String.valueOf(sb);
		
		//convert objet to customer and make a csv record
		 return a;
	}
	@Override
	protected Object csvRecordToObject(String cvsRecord) {
		//create a customer object from csvrecord
		
		
		String[] str = cvsRecord.split(",");
		
		int a = Integer.valueOf(str[0]);
		String b = String.valueOf(str[1]);
		float c = Float.valueOf(str[2]);

		Item it = new Item(a,b,c);
		 
		return it;
		
	}
}

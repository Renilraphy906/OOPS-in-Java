package com.aitrich.inventorysystem.domain;

public class Customer {
	
	String customername;
	String billingaddress;
	String emailaddress;
	
	public Customer()
	{
		this.customername = null;
		this.billingaddress = null;
		this.emailaddress = null;
	}
	
	public Customer(String customername, String billingaddress, String emailaddress )
	{
		this.customername = customername;
		this.billingaddress = billingaddress;
		this.emailaddress = emailaddress;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getBillingaddress() {
		return billingaddress;
	}

	public void setBillingaddress(String billingaddress) {
		this.billingaddress = billingaddress;
	}

	public String getEmailaddress() {
		return emailaddress;
	}

	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}

	@Override
	public String toString() {
		return "Customer [customername=" + customername + ", billingaddress=" + billingaddress + ", emailaddress="
				+ emailaddress + "]";
	}
	 
}

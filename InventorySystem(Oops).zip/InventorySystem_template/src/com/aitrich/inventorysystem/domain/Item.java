package com.aitrich.inventorysystem.domain;

public class Item {
	 
	private int itemnumber;
	private String itemname;
	private float unitprice;
	
	public Item()
	{
		this.itemnumber = 0;
		this.itemname = null;
		this.unitprice = 0;
	}
	
	public Item(int itemnumber, String itemname, float unitprice)
	{
		this.itemnumber = itemnumber;
		this.itemname = itemname;
		this.unitprice = unitprice;
	}

	public int getItemnumber() {
		return itemnumber;
	}

	public void setItemnumber(int itemnumber) {
		this.itemnumber = itemnumber;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public float getUnitprice() {
		return unitprice;
	}

	public void setUnitprice(float unitprice) {
		this.unitprice = unitprice;
	}

	@Override
	public String toString() {
		
		StringBuilder sb = new StringBuilder();
		sb.append("Item [");
		if(this.itemnumber != 0)
		{
			sb.append("itemnumber=");
			sb.append(itemnumber);
			sb.append(",");
		}
		if(!this.itemname.equals(null))
		{
			sb.append("itemname=");
			sb.append(itemname);
			sb.append(",");
		}
		if(this.unitprice != 0)
		{
			sb.append("unitprice=");
			sb.append(unitprice);
			sb.append("]");
		}
		return  sb.toString();
	}
}
